package com.student.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.project.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
