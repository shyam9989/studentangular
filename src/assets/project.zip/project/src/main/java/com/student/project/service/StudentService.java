package com.student.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.project.model.Student;
import com.student.project.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;

	public List<Student> getStudents() {

		return studentRepository.findAll();

	}
	
	public List<Student> addStudent(Student student) {
		
		studentRepository.save(student);
		
		return studentRepository.findAll();
		
	}

	public List<Student> updateStudent(Student stu) {
		System.out.println(stu);
		studentRepository.save(stu);
		return studentRepository.findAll();
		
	}

	public List<Student> deleteStudent(int studentId) {
		Student stu1=studentRepository.getReferenceById(studentId);
		studentRepository.delete(stu1);
		return studentRepository.findAll();
	}
}
