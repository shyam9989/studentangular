package com.student.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.student.project.model.Student;
import com.student.project.service.StudentService;

@RestController
@RequestMapping("/student")
@CrossOrigin(origins = "*")
public class StudentController {

	@Autowired
	StudentService studentService;

	@GetMapping("/students")
	public List<Student> getStudentController() {

		return studentService.getStudents();

	}

	@PostMapping("/students")
	public List<Student> insertStudent(@RequestBody Student student) {
System.out.println(student.toString());
		
		return studentService.addStudent(student);

	}

	@PutMapping("/students/{studentId}")
	public List<Student> updateDelete(@PathVariable int studentId,@RequestBody Student student) {
		System.out.println(student.getStudentId());

		return studentService.updateStudent(student);

	}

	@DeleteMapping("/students/{studentId}")
	public List<Student> deleteDelete(@PathVariable int studentId) {
		System.out.println(studentId);
		return studentService.deleteStudent(studentId);

	}

}
